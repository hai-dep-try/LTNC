
interface WifiConnectable {
    void connectWifi();
}
