interface CanSwim {
    void swim();
}
