interface CanFight {
    void fight();
}
